package com.jdbc.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import com.jdbc.delete.Delete;
import com.jdbc.display.Display;
import com.jdbc.insert.Insert;
import com.jdbc.update.Update;

public class Test {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver is loaded...");
		
		String url = "jdbc:mysql://localhost:3306/stud?useSSL=false";
		String uname = "root";
		String pass = "Cartoon_34";
		
		Scanner sc = new Scanner(System.in);
		
		Connection connection = DriverManager.getConnection(url, uname, pass);
		if(connection != null) {
			System.out.println("Connection is Successfully...");
			boolean flag = true;
			while(flag) {
				
				System.out.println("\n1.Insert\n2.Update\n3.Delete\n4.Display\n5.Exit");
				System.out.println("Enter your Choice:");
				int ch = sc.nextInt();
				switch (ch) {
				case 1: int t;
						do {
							System.out.println("Enter the Id:");
							int id = sc.nextInt();
							
							System.out.println("Enter the First Name:");
							String fname = sc.next();
							
							System.out.println("Enter the Last Name:");
							String lname = sc.next();
							
							Insert.insertion(connection,id,fname,lname);
							
							System.out.println("You want to continue then Enter 1 or Exit then Enter 0:");
							int t1 = sc.nextInt();
							t = t1;
						} while(t==1);
						
						break;
						
				case 2:	System.out.println("Ente the Id you want to Change:");
				   		int id1 = sc.nextInt();
						System.out.println("Enter the New First Name:");
						String nfname = sc.next();
						System.out.println("Enter the New Last Name:");
						String nlname = sc.next();
						
						Update.update(connection,id1,nfname,nlname);
						break;
				case 3:	Delete.delete(connection);
						break;
				
				case 4:	System.out.println("...Display Records...\n");
						System.out.println("Id\tFName\tLName");
						Display.display(connection);
						break;

				case 5:	connection.close();
						flag = false;
						break;
				}
				
			}
			
		}else {
			System.out.println("Connection is failed...");
		}
		connection.close();
		
	}

}












