package com.jdbc.update;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Update {
	
	public static void update(Connection connection,int id1,String nfname,String nlname) {
		
		String update = "update stud set fname=?,lname=? where id=?";
		
		try {
			PreparedStatement ps = connection.prepareStatement(update);
			ps.setInt(3, id1);
			ps.setString(1,nfname);
			ps.setString(2,nlname);
			ps.executeUpdate();
			System.out.println("...Record Updated Successfully...");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}












