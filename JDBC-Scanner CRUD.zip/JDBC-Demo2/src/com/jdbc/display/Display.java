package com.jdbc.display;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Display {
	
	public static void display(Connection connection) {
		
		Statement st;
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from stud");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}






