package com.jdbc.insert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Insert {
	
	public static void insertion(Connection connection,int id,String fname,String lname) {
		
		String insert = "insert into stud values(?,?,?)";
		
		try {
			PreparedStatement ps = connection.prepareStatement(insert);
			ps.setInt(1,id);
			ps.setString(2,fname);
			ps.setString(3,lname);
			
			ps.executeUpdate();
			System.out.println("...Record Inserted...");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}














