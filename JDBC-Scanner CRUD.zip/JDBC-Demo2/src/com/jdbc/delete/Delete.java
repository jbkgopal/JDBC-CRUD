package com.jdbc.delete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Delete {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void delete(Connection connection) {
		
		String delete = "delete from stud where id = ?";
		String truncate = "truncate table stud";
		
		try {
			
			boolean flag = true;
			while(flag) {
				
				System.out.println("\n1.Delete One Record\n2.All Data Delete\n3.Exit");
				System.out.println("Enter your Choice:");
				int ch1 = sc.nextInt();
				switch(ch1) {
				case 1:	System.out.println("Enter Id you want to delete:");
		 				int id2 = sc.nextInt();
		 				PreparedStatement ps = connection.prepareStatement(delete);
		 				ps.setInt(1,id2);
		 				ps.executeUpdate();
		 				System.out.println("...Id no."+id2+" Deleted Successfully...");
						break;
				case 2: PreparedStatement ps1 = connection.prepareStatement(truncate);
						ps1.executeUpdate();
						System.out.println("...All Data Deleted...");
						break;
				case 3:	flag = false;
						break;
				
				}
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}










